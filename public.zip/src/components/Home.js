import React from "react";

const Home = () => {
  return (
    <div>
      <h1>Welcome to Demo Retail Store</h1>
      <p>Your one-stop shop for all things amazing!</p>
    </div>
  );
};

export default Home;