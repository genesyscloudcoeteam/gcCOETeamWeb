import React from "react";

const Footer = () => {
  return (
    <footer>
      <p>&copy; 2024 Genesys Cloud COE Team Demo Retail Website</p>
    </footer>
  );
};

export default Footer;